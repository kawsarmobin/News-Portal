<?php

return [
    'topic_check' => false 
];