 
<?php $__env->startSection('content'); ?>
<div class="col-lg-10 p-5">
    <div class="my-4">
        <section id="topics" style="background-color: #FFFFFF">
            <div class="row justify-content-center">
                <div class="col-lg-10 p-5">
                    <div class="text-center text-primary">
                        <h2>Posts Link</h2>
                        <hr>
                    </div>
                    <div class="row" style="margin-right: 15px">
                        <ol style="width: 100%">
                            <?php $__currentLoopData = $post_link_lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pll): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div style="border: 1px solid gray; border-radius: 5px; padding: 10px 20px 0px 20px" class="m-2">
                                <li>
                                    <h5 class="float-left"><?php echo e($pll->title); ?></h5>
                                    <!-- The button used to copy the text -->
                                    <button class="float-right btn btn-sm btn-outline-primary" onclick="CopyToClipboard('copy<?php echo e($pll->id); ?>')" style="margin-bottom: 15px;">Copy</button>
                                </li>
                                <input class="form-control" id="copy<?php echo e($pll->id); ?>" type="text" value="<?php echo e(route('post.single.page', $pll->token)); ?>" readonly><br>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ol>
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>