 
<?php $__env->startSection('content'); ?>
<!--Left-->
    <?php echo $__env->make('includes.frontend.left_side', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!--Center-->
<div class="col-lg-7 col-sm-12 main-tab" style="font-family: lato">
    <div class="my-4">
        <div class="main-heading">
            <div class="p-2 text-center">
                <h4 class="text-capitalize"><?php echo e($title); ?></h4>
            </div>
        </div>
        <?php if($data): ?>
        <section class="card mb-3">
            <div class="card-body text-justify">
                <p><?php echo $data->description; ?></p>
            </div>
        </section>
        <?php else: ?>
        <section class="card mb-3">
            <div class="card-body">
                <h4 class="text-center">No <span class="text-lowercase"><?php echo e($title); ?></span></h4>
            </div>
        </section>
        <?php endif; ?>
    </div>
</div>
<!--Right-->
    <?php echo $__env->make('includes.frontend.right_side', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>