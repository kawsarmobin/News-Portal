 
<?php $__env->startSection('content'); ?>
<div class="col-lg-10 p-5">
    <div class="my-4">
        <div class="card" id="profiles">
            <div class="card-body">
                <div class="row justify-content-center">
                    <div class="col-lg-10 p-5">
                        <h3>My Information update</h3>
                        <hr>
                        <div class="row">
                            <div class="col-md-12">
                                <form action="<?php echo e(route('profile.store')); ?>" method="post" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group">
                                        <label for="name">Name *</label>
                                        <input class="form-control <?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" type="text" name="name" value="<?php echo e(old('name',  $profile->name)); ?>"
                                            placeholder="Enter Name"> <?php if($errors->has('name')): ?>
                                        <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($errors->first('name')); ?></strong>
                                            </span> <?php endif; ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="email">Email *</label>
                                        <input class="form-control <?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" type="email" name="email" value="<?php echo e(old('email',  $profile->email)); ?>"
                                            placeholder="Enter email"> <?php if($errors->has('email')): ?>
                                        <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($errors->first('email')); ?></strong>
                                            </span> <?php endif; ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="website">Website</label>
                                        <input class="form-control <?php echo e($errors->has('website') ? ' is-invalid' : ''); ?>" type="url" name="website" value="<?php echo e(old('website',  $profile->website)); ?>"
                                            placeholder="Enter website"> 
                                            <?php if($errors->has('website')): ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($errors->first('website')); ?></strong>
                                                </span> 
                                            <?php endif; ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="sub_title">Sub Title</label>
                                        <input class="form-control <?php echo e($errors->has('sub_title') ? ' is-invalid' : ''); ?>" type="text" name="sub_title" value="<?php echo e(old('sub_title',  $profile->sub_title)); ?>"
                                            placeholder="Enter Sub Title"> 
                                            <?php if($errors->has('sub_title')): ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($errors->first('sub_title')); ?></strong>
                                                </span> 
                                            <?php endif; ?>
                                    </div>
                                    
                                    <?php if($profile->avatar): ?>
                                    <div class="form-group">
                                        <div class="row">
                                            <div class="col-md-3">
                                                <div class="img-thumbnail" width="80%">
                                                    <img src="<?php echo e($profile->user_avatar); ?>" width="100%" alt="">
                                                    <div class="caption text-center"><span class="badge badge-success">Old Avatar</span></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                    <div class="form-group">
                                        <label for="avatar">Avatar</label><br>
                                        <input class="<?php echo e($errors->has('avatar') ? ' is-invalid' : ''); ?>" type="file" name="avatar">                                        
                                        <?php if($errors->has('avatar')): ?> <br>
                                            <strong style="font-size: 80%" class="text-danger"><?php echo e($errors->first('avatar')); ?></strong>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group">
                                        <button type="submit" class="btn btn-outline-secondary btn-sm button">Update</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>