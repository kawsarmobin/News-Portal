 
<?php $__env->startSection('content'); ?>
<div class="row clearfix">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="card">
            <div class="header">
                <h2>TERMS</h2>
            </div>
            <?php echo $__env->make('includes.errors', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <div class="body">
                <form action="<?php echo route('terms.store'); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <textarea id="ckeditor" name="description"><?php echo $term->description; ?></textarea> <br>
                   
                    <button type="submit" class="btn bg-blue-grey waves-effect pull-right">Submit</button> <br>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.custom', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>