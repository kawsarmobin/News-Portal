<?php $__env->startSection('content'); ?>
<div class="col-lg-10 p-5">
    <div class="my-4">
        <div class="card" id="profiles">
            <div class="card-body">
                <div class="row justify-content-center">
                    <div class="col-lg-10 p-5">
                        <h3>Change Password</h3>
                        <hr>
                        <div class="row">
                            <div class="col-md-12">
                                <form action="<?php echo e(route('profile.update-password')); ?>" method="post" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group">
                                        <label for="password"><?php echo e(__('New Password')); ?></label>

                                        <input id="password" type="password"
                                            class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>"
                                            name="password" required>

                                        <?php if($errors->has('password')): ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($errors->first('password')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                    </div>

                                    <div class="form-group">
                                        <label for="password-confirm"><?php echo e(__('Confirm Password')); ?></label>
                                        <input id="password-confirm" type="password" class="form-control"
                                            name="password_confirmation" required>
                                    </div>
                                    <div class="form-group">
                                        <button type="submit"
                                            class="btn btn-outline-secondary btn-sm button">Update</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>