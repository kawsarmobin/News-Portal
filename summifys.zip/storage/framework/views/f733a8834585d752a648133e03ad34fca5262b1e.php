<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<section class="card pb-4 mb-3">
    <!--Main content-->
    <div class=" pr-3 pl-3 mr-3 ml-3 mt-3">
        <div class="row">
            <div class="col-9 cus-font">
                <div>
                    <h2 class="post-title cus-font"><b><a style="text-decoration: none; "  href="<?php echo e(route('post.single.page', $post->token)); ?>"><?php echo e($post->title); ?></a></b></h2>
                </div>
                <div>
                    <p class="cus-font" style="font-size: 15px; margin: 0"><b><?php echo e($post->topic->name); ?></b> &nbsp; <span style="color: gray"><?php echo e($post->created_at->diffForHumans()); ?></span></p>
                </div>
                <div class="post-text">
                    <div>
                        <p class="text-justify cus-font"><?php echo $post->summery; ?></p>
                    </div>
                    <?php if($post->source_link): ?>
                    <div>
                        <p class="cus-font" style="margin-top: -10px;"><b>Source:</b> <a href="<?php echo e($post->source_link); ?>" target="_blank"><?php echo e(str_limit($post->source_link, 30)); ?></a></p>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-3">
                <!--Vote option-->
                <div style="padding: 0 0 0 18px; margin-top: 80%;">
                    <app-vote :post="<?php echo e($post); ?>"></app-vote>
                </div>
            </div>
        </div>
    </div>
    <p class="bg-secondary text-white pl-2 cus-font">Kindly Summarized by</p>
    <div class="row post-part" style="margin-top: -25px;">
        <!--Avatar-->
        <div class="row m-0 p-0 avater" style="width: 100%;">
            <div class="col-2 ">
                <?php if($post->user->avatar): ?>
                <img class="m-4" style="border-radius: 50%; width:50px; height:50px; object-fit: cover; display: block;" src="<?php echo e($post->user->avatar_thumbnail); ?>" alt="AVATAR"> 
                <?php else: ?>
                <img class="m-4" style="border-radius: 50%; width:50px; height:50px; object-fit: cover; display: block;" src="<?php echo e(asset('img/avatar.gif')); ?>" alt="Image Not Found"> 
                <?php endif; ?>
            </div>
            <div class="col-10">
                <div class="mt-4 avater-name cus-font">
                    <!--Website name / User name-->
                    <?php if($post->user->website): ?>
                    <a href="<?php echo e($post->user->website); ?>" target="_blank"><?php echo e($post->user->website); ?></a>                    
                    <?php else: ?>
                    <span class="cus-font"><?php echo e($post->user->name); ?></span> 
                    <?php endif; ?>
                    <p>
                        <!--Sybtitle-->
                        <?php if($post->user->sub_title): ?>
                        <span class="cus-font" style="color: gray"><?php echo e($post->user->sub_title); ?></span> 
                        <?php endif; ?>
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>