 
<?php $__env->startSection('content'); ?>
<div class="col-lg-10 p-5">
    <div class="my-4">
        <section id="topics" style="background-color: #FFFFFF">
            <div class="row justify-content-center">
                <div class="col-lg-10 p-5">
                    <div class="row">
                        <div class="col-lg-6">
                            <h3><b>Posts</b></h3>
                        </div>
                        <div class="col-lg-6">
                            <a class="btn btn-primary btn-sm float-right" style="margin-top: 8px" href="<?php echo e(route('own-posts.create')); ?>">Add New Post</a>
                        </div>
                    </div>
                    <hr>
                    <?php if($posts->count()): ?>
                    <div style="border: 1px solid rgba(0, 0, 0, 0.1)">
                        <table class="table table-striped" style="margin-bottom: 0rem;">
                            <tbody>
                                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><span style="color: #007ACC !important"><b><?php echo e($post->title); ?></b></span></td>
                                    <td width="23%">
                                        <a href="<?php echo e(route('own-posts.show', $post->id)); ?>" class="btn btn-sm btn-outline-info"><i class="fa fa-eye"></i> </a> &nbsp;
                                        <a href="<?php echo e(route('own-posts.edit', $post->id)); ?>" class="btn btn-sm btn-outline-primary"><i class="fa fa-edit"></i> </a> &nbsp;
                                        <?php echo $__env->make('includes._confirm_delete',[
                                            'id' => $post->id,
                                            'action' => route('own-posts.destroy', $post->id) 
                                        ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <?php else: ?> 
                    <h4>No posts yet...</h4>
                    <?php endif; ?>
                </div>
            </div>
        </section>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>