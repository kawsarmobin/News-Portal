<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
    <div class="card" style="overflow: hidden">
        <div class="header">
            <h2>
                Change Password
            </h2>
        </div>
        <div class="body">
            <form action="<?php echo e(route('admin.profile.store')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="col-md-6" style="margin-bottom: 0 !important">
                    <label for="name">Name</label>
                    <div class="form-group">
                        <div class="form-line">
                            <input class="form-control <?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" type="text"
                                    name="name" value="<?php echo e(old('name',  $profile->name)); ?>" placeholder="Enter Name">
                        </div>
                        <?php if($errors->has('password')): ?>
                        <span class="" role="alert">
                            <strong class="input-error"><?php echo e($errors->first('password')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                    <label for="website">Website</label>
                    <div class="form-group">
                        <div class="form-line">
                            <input class="form-control <?php echo e($errors->has('website') ? ' is-invalid' : ''); ?>"
                                    type="url" name="website" value="<?php echo e(old('website',  $profile->website)); ?>"
                                    placeholder="Enter website">
                        </div>
                        <?php if($errors->has('password')): ?>
                        <span class="" role="alert">
                            <strong class="input-error"><?php echo e($errors->first('password')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-md-6" style="margin-bottom: 0 !important">
                    <label for="email">Email</label>
                    <div class="form-group">
                        <div class="form-line">
                            <input class="form-control <?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>"
                                    type="email" name="email" value="<?php echo e(old('email',  $profile->email)); ?>"
                                    placeholder="Enter email">
                        </div>
                        <?php if($errors->has('password')): ?>
                        <span class="" role="alert">
                            <strong class="input-error"><?php echo e($errors->first('password')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                    <label for="avatar">Avatar</label><br>
                    <div class="form-group">
                        <input class="<?php echo e($errors->has('avatar') ? ' is-invalid' : ''); ?>" type="file"
                                    name="avatar">
                        <?php if($errors->has('password')): ?>
                        <span class="" role="alert">
                            <strong class="input-error"><?php echo e($errors->first('password')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-md-12">
                    <button type="submit" class="btn btn-primary m-t-15 waves-effect">Update</button>
                </div>
            </form>
        </div>
    </div>
</div>
