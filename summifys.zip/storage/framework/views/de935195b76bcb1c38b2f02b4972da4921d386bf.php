<div class="form-group">
    <label for="topic">Topic</label>
    <select class="form-control<?php echo e($errors->has('topic') ? ' is-invalid' : ''); ?>" name="topic" id="topic">
      <option value="">Pick a topic</option>
      <?php $__currentLoopData = $topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option <?php echo e(old('topic', $post->topic_id) == $topic->id ? 'selected' : ''); ?> value="<?php echo e($topic->id); ?>"><?php echo e($topic->name); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>

    <?php if($errors->has('topic')): ?>
        <span class="invalid-feedback" role="alert">
            <strong><?php echo e($errors->first('topic')); ?></strong>
        </span>
    <?php endif; ?>
  </div>
<div class="form-group">
    <label class="control-label">Title: </label>
    <input class="post_title form-control<?php echo e($errors->has('title') ? ' is-invalid' : ''); ?>" id="the-textarea" maxlength="80" type="text" name="title" value="<?php echo e(old('title', $post->title)); ?>" placeholder="Enter your title" autofocus>
    
    <div class="float-right" id="the-title-count">
        <span id="current_title">0</span>
        <span id="maximum_title">/ 80</span>
    </div>

    <?php if($errors->has('title')): ?>
        <span class="invalid-feedback" role="alert">
            <strong><?php echo e($errors->first('title')); ?></strong>
        </span>
    <?php endif; ?>
</div>
<div class="form-group">
    <label class="control-label">Summery: </label>
    
    <textarea class="post_textarea form-control<?php echo e($errors->has('summery') ? ' is-invalid' : ''); ?>" id="the-textarea" maxlength="400" name="summery" cols="30" rows="6" autofocus><?php echo e(old('summery', $post->summery)); ?></textarea>
    <div class="float-right" id="the-count">
        <span id="current">0</span>
        <span id="maximum">/ 400</span>
    </div>
    <?php if($errors->has('summery')): ?>
        <span class="invalid-feedback" role="alert">
            <strong><?php echo e($errors->first('summery')); ?></strong>
        </span>
    <?php endif; ?>
</div>
<div class="form-group">
    <label class="control-label">Source Link: </label>
    <input class="form-control<?php echo e($errors->has('source_link') ? ' is-invalid' : ''); ?>" type="url" name="source_link" value="<?php echo e(old('source_link', $post->source_link)); ?>" placeholder="Enter source link">
    
    <?php if($errors->has('source_link')): ?>
        <span class="invalid-feedback" role="alert">
            <strong><?php echo e($errors->first('source_link')); ?></strong>
        </span>
    <?php endif; ?>
</div>
<div class="form-group">
    <button type="submit" class="btn btn-outline-secondary btn-sm button"><?php echo e($actionTitle); ?></button>
</div>