<?php $__env->startSection('content'); ?>
<div class="row clearfix">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="card">
            <div class="header">
                <h2>Profile</h2>
            </div>
            <div class="body">
                <div class="row">
                    <div>
                        <div class="col-md-6 admin-profile-view">
                            <?php if($profile->avatar): ?>
                            <img src="<?php echo e($profile->user_avatar); ?>" width="50%" alt="">
                            <?php else: ?>
                            <img src="<?php echo e(asset('img/avatar.gif')); ?>" width="50%" alt="">
                            <?php endif; ?>
                        </div>
                        <div class="col-md-6">
                            <table class="table no-border cus-padding">
                                <tr>
                                    <td width="5px"><b>Name</b></td>
                                    <td width="1px"><b> : </b></td>
                                    <td><?php echo e($profile->name); ?></td>
                                </tr>
                                <tr>
                                    <td><b>Email</b></td>
                                    <td><b> : </b></td>
                                    <td><?php echo e($profile->email); ?></td>
                                </tr>
                                <tr>
                                    <td><b>Website</b></td>
                                    <td><b> : </b></td>
                                    <td><?php echo e($profile->website); ?></td>
                                </tr>
                            </table>
                            <a href="<?php echo e(route('admin.profile.update')); ?>" class="btn btn-sm btn-primary">Update
                                Profile</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.custom', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>