 
<?php $__env->startSection('content'); ?>
<!--Left-->
    <?php echo $__env->make('includes.frontend.left_side', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!--Center-->
<div class="col-lg-7 col-sm-12 main-tab" style="font-family: lato;">
    <div class="my-4">
        <div class="main-heading">
            <div class="p-2 text-center"><h4><?php echo e(isset($topic)?$topic->name:null); ?> <?php echo e(isset($date_data)?$date_data:null); ?></h4></div>
        </div>
        <?php if($posts->count()): ?>
        <!--Include posts segment-->
            <?php echo $__env->make('includes.frontend.posts_segment', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!--Pagination-->
        <div class="row justify-content-center">
            <div class="col-md-6">
                <?php echo e($posts->links()); ?>

            </div>
        </div>
        <!--If post not found-->
        <?php else: ?>
        <div class="card bg-light text-dark text-center" style="margin-top: 18px;">
            <div class="card-body">
                <h2>No posts yet...</h2>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>
<!--Right-->
    <?php echo $__env->make('includes.frontend.right_side', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>