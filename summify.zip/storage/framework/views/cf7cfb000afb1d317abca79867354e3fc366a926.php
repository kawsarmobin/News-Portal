<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css?family=Roboto:400,700&subset=latin,cyrillic-ext" rel="stylesheet" type="text/css">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet" type="text/css">

<!-- Bootstrap Core Css -->
<link href="<?php echo e(asset('master/plugins/bootstrap/css/bootstrap.css')); ?>" rel="stylesheet">

<!-- Waves Effect Css -->
<link href="<?php echo e(asset('master/plugins/node-waves/waves.css')); ?>" rel="stylesheet" />

<!-- Animation Css -->
<link href="<?php echo e(asset('master/plugins/animate-css/animate.css')); ?>" rel="stylesheet" />

<!-- Morris Chart Css-->
<link href="<?php echo e(asset('master/plugins/morrisjs/morris.css')); ?>" rel="stylesheet" />

<!-- Custom Css -->
<link href="<?php echo e(asset('master/css/style.css')); ?>" rel="stylesheet">

<!-- Toaster Css -->
<link href="<?php echo e(asset('css/toastr.min.css')); ?>" rel="stylesheet">

<!-- AdminBSB Themes. You can choose a theme from css/themes instead of get all themes -->
<link href="<?php echo e(asset('master/css/themes/all-themes.css')); ?>" rel="stylesheet" />