 
<?php $__env->startSection('content'); ?>
<div class="col-lg-10 p-5">
    <div class="my-4">
        <section id="topics" style="background-color: #FFFFFF">
            <div class="row justify-content-center">
                <div class="col-lg-10 p-5">
                    <div class="text-center text-primary">
                        <h2><?php echo e($post->title); ?></h2>
                        <hr>
                    </div>
                    <div class="form-group text-center">
                        <input class="form-control" id="copy<?php echo e($post->id); ?>" type="text" value="<?php echo e(route('post.single.page', $post->token)); ?>" readonly>
                    </div>
                    <div class="row">
                        <div class="col-lg-6">
                            <!-- The button used to copy the text -->
                            <button class="btn btn-sm btn-outline-secondary" onclick="CopyToClipboard('copy<?php echo e($post->id); ?>')" style="margin-bottom: 15px;">Copy</button>
                        </div>
                        <div class="col-lg-6">
                            <a class="btn btn-outline-primary btn-sm float-right" href="<?php echo e(route('own-posts.show', $post->id)); ?>">View Your New Post</a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>