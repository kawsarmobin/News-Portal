 
<?php $__env->startSection('content'); ?>
<div class="row clearfix">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="card">
            <div class="header">
                <h2 class="text-uppercase">
                    All Users
                </h2>
            </div>
            <div class="body">
                <table class="table table-bordered table-striped table-hover js-basic-example dataTable">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Name</th>
                            <th scope="col">Email</th>
                            <th scope="col">Role</th>
                            <th scope="col">Status</th>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e(++$key); ?></th>
                            <td><?php echo e($user->name); ?></td>
                            <td><?php echo e($user->email); ?></td>
                            <td>
                                <?php echo e($user->user_role); ?> | 
                                <a class="badge bg-primary" href="<?php echo e(route('admin.users.role', $user->id)); ?>"><?php echo e($user->is_admin?'Regular User':'Admin'); ?></a>
                            </td>
                            <td>
                                <?php echo e($user->status); ?> | 
                                <a class="badge bg-primary" href="<?php echo e(route('admin.users.status', $user->id)); ?>"><?php echo e($user->is_active?'Deactive':'Active'); ?></a>
                            </td>
                            <td>
                                <?php echo $__env->make('includes._admin_confirm_delete',[
                                    'action' => route('admin.users.destroy', $user->id),
                                    'id' => $user->id
                                ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.custom', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>