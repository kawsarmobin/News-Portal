 
<?php $__env->startSection('content'); ?>
<div class="col-lg-8">

    <div class="my-4">
        <section id="example1">
            <h1>The Man Who Was Almost Killed By 'Don Quixote'</h1>
        </section>
    </div>

</div>
<div class="col-lg-2">

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>