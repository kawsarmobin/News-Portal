 
<?php $__env->startSection('content'); ?>
<!--Left-->
    <?php echo $__env->make('includes.frontend.left_side', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!--Center-->
<div class="col-lg-7 col-sm-12 main-tab" style="font-family: lato;">
    <div class="my-4">
        <!--Recent post-->
        <?php echo $__env->make('includes.top_panel', ['title'=>'New'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        
        <?php if($posts->count()): ?>
        <!--Include posts segment-->
    <?php echo $__env->make('includes.frontend.posts_segment', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <!--Pagination-->
        <div class="row justify-content-center">
            <div class="col-lg-6">
                <?php echo e($posts->links()); ?>

            </div>
        </div>
        <!--If post not found-->
        <?php else: ?>
        <div class="card bg-light text-dark text-center" style="margin-top: 18px;">
            <div class="card-body">
                <h2>No posts yet...</h2>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>
<!--Right-->
    <?php echo $__env->make('includes.frontend.right_side', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>