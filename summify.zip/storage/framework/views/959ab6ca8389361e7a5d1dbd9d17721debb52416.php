 
<?php $__env->startSection('content'); ?>
<!--Left-->
    <?php echo $__env->make('includes.frontend.left_side', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!--Center-->
<div class="col-lg-7 col-sm-12 main-tab" style="font-family: lato">
    <div class="my-4">
        <div class="main-heading">
            <div class="p-2 text-center"><h4>Posts Archive</h4></div>
        </div>
        <?php if($posts->count()): ?> <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <section class="card pb-4 mb-3">
            <div class="row post-part">
                <!--Avatar-->
                <div class="row m-0 p-0 avater" style="width: 100%;">
                    <div class="col-2 ">
                        <?php if($post->user->avatar): ?>
                        <img class="m-4" style="border-radius: 50%; width:50px; height:50px; object-fit: cover; display: block;" src="<?php echo e($post->user->avatar_thumbnail); ?>" alt="AVATAR"> 
                        <?php else: ?>
                        <img class="m-4" style="border-radius: 50%; width:50px; height:50px; object-fit: cover; display: block;" src="<?php echo e(asset('img/avatar.gif')); ?>" alt="Image Not Found"> 
                        <?php endif; ?>
                    </div>
                    <div class="col-10">
                        <div class="mt-4 avater-name">
                            <!--Website name / User name-->
                            <?php if($post->user->website): ?>
                            <a style="text-decoration: none;" href="<?php echo e($post->user->website); ?>" target="_blank"><?php echo e($post->user->website); ?></a>                    
                            <?php else: ?>
                            <span style="text-decoration: none;"><?php echo e($post->user->name); ?></span> 
                            <?php endif; ?>
                            <p>
                                <!--Sybtitle-->
                                <?php if($post->user->sub_title): ?>
                                <span style="color: gray"><?php echo e($post->user->sub_title); ?></span> 
                                <?php endif; ?>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <!--Main content-->
            <div class="card p-3 m-3">
                <div>
                    <h2><b><a style="text-decoration: none;" href="<?php echo e(route('post.single.page', $post->token)); ?>"><?php echo e($post->title); ?></a></b></h2>
                </div>
                <div>
                    <p style="font-size: 15px; margin: 0"><b><?php echo e($post->topic->name); ?></b> &nbsp; <span style="color: gray"><?php echo e($post->created_at->diffForHumans()); ?></span></p>
                </div>
                <div style="padding-left: 20px">
                    <div>
                        <p><b><?php echo $post->summery; ?></b></p>
                    </div>
                    <?php if($post->source_link): ?>
                    <div>
                        <p style="margin-top: -10px;">Source: <a style="text-decoration: none;" href="<?php echo e($post->source_link); ?>" target="_blank"><?php echo e(str_limit($post->source_link, 30)); ?></a></p>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <!--Vote option-->
            <div style="padding: 0 0 0 18px">
                <app-vote :post="<?php echo e($post); ?>"></app-vote>
            </div>
        </section>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <!--Pagination-->
        <div class="row justify-content-center">
            <div class="col-md-6">
                <?php echo e($posts->links()); ?>

            </div>
        </div>
        <!--If post not found-->
        <?php else: ?>
        <div class="card-body text-center">
            <h2>No posts yet...</h2>
        </div>
        <?php endif; ?>
    </div>
</div>
<!--Right-->
    <?php echo $__env->make('includes.frontend.right_side', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>