<?php if(config('topics.topic_change')): ?>
<div class="col-lg-3 col-sm-12 mt-4 navbar-expand-lg navbar-light">
    <div class="custom-topic-header">
        <div class="d-flex">
            <div class="">
                <p>
                    <?php if(auth()->check()): ?>
                    My
                    <?php endif; ?>
                    Topics
                </p>
            </div>
            <div class="ml-auto p-2">
                <button class="navbar-toggler topic-toggle-button" type="button" data-toggle="collapse" data-target="#topicNav"
                    aria-controls="topicNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
            </div>
        </div>
    </div>
    <div class="topics-card">

        <div class="topic-item">
            <?php if($num_of_topics = $topics->count()): ?>
                <div class="collapse navbar-collapse" id="topicNav">
                    <ul class="topic-nav-ul">
                        <?php $__currentLoopData = $topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-unstyled">
                                <a href="<?php echo e(route('topic.posts', ['slug' => $topic->slug])); ?>">
                                    <i class="fa fa-angle-double-right" aria-hidden="true"></i> <?php echo e($topic->name); ?>

                                </a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php else: ?>
            <div>
                <h5>No topics yet...</h5>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php endif; ?>