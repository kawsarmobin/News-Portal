<a href="" data-toggle="modal" class="text-danger" data-target="#deleteConfirm-<?php echo e($id); ?>"><i class="material-icons">delete_outline</i></a>
<!-- Modal -->
<div class="modal fade" id="deleteConfirm-<?php echo e($id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header bg-red">
        <h5 class="modal-title" id="exampleModalLabel">Delete Confirmation???</h5>
        <br>
      </div>
      <form action="<?php echo e($action); ?>" method="post">
        <?php echo csrf_field(); ?> <?php echo method_field('delete'); ?>
            <div class="modal-body">
                <h3>Are you sure want to delete this?</h3>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-sm btn-success" data-dismiss="modal">No</button>
                <button type="submit" class="btn btn-sm btn-danger">Yes</button>
            </div>
      </form>
     
    </div>
  </div>
</div>