 
<?php $__env->startSection('content'); ?>
<div class="col-lg-10 p-5">
    <div class="my-4">
        <section id="topics" style="background-color: #FFFFFF">
            <div class="row justify-content-center">
                <div class="col-lg-10 p-5">
                    <div class="row">
                        <div class="col-lg-6">
                            <h3><b>Topics</b></h3>
                        </div>
                    </div>
                    <hr>
                    <?php if(count($topics)): ?>
                    <div style="border: 1px solid rgba(0, 0, 0, 0.1)">
                        <table class="table table-striped" style="margin-bottom: 0rem;">
                            <tbody>
                                <?php $__currentLoopData = $topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td style=" padding: 5px"><span class="pl-3" style="color: #007ACC !important"><b><?php echo e($topic['name']); ?></b></span></td>

                                    <?php if(auth()->check()): ?>
                                    <td style=" padding: 5px">
                                        <a style="text-decoration: none" href="<?php echo e(route('topic.follows.follow', $topic['id'])); ?>" class="<?php echo e($topic->isFollowed()?'text-secondary':'text-primary'); ?>"><?php echo e($topic->isFollowed()?'Unfollow':'Follow'); ?></a> 
                                    </td>
                                    <?php else: ?>
                                        <td style=" padding: 5px">
                                            <a style="text-decoration: none" href="<?php echo e(route('topic.follows.follow', $topic['id'])); ?>" class="text-primary">Follow</a> 
                                        </td>
                                    <?php endif; ?>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <?php else: ?> 
                        <div class="card-body text-center">
                            <h2>No topics yet...</h2>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </section>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>