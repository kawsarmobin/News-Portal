<!--Changed by buyer-->
<div class="d-flex cus-font">
        <div class="mr-auto p-2">
                
        </div>
        <div class="p-2"><a href="<?php echo e(route('home.new')); ?>">New</a></div>
        <div class="p-2"><a href="<?php echo e(route('home.popular')); ?>">Popular</a></div>
</div>