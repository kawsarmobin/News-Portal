<?php $__env->startSection('content'); ?>
<div class="row clearfix">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="card">
            <div class="header">
                <h2 class="text-uppercase">
                    Post
                </h2>
            </div>
            <div class="body">
                <table class="table text-justify no-border cus-padding">
                    <tr>
                        <td style="width: 95px">Topic</td>
                        <td style="width: 1px">:</td>
                        <td><?php echo e($post->topic->name); ?></td>
                    </tr>
                    <tr>
                        <td>Title</td>
                        <td>:</td>
                        <td><?php echo e($post->title); ?></td>
                    </tr>
                    <tr>
                        <td>Summery</td>
                        <td>:</td>
                        <td><?php echo $post->summery; ?></td>
                    </tr>
                </table>
                <hr>
                <table class="table text-justify no-border cus-padding">
                    <?php if($post->source_link): ?>
                    <tr>
                        <td>Source Link</td>
                        <td>:</td>
                        <td><?php echo e(str_limit($post->source_link, 30)); ?></td>
                    </tr>
                    <?php endif; ?>
                    <tr>
                        <td style="width: 95px; padding-top: 12px;">Post Link</td>
                        <td style="width: 1px; padding-top: 12px;">:</td>
                        <td><input class="form-control" type="text" value="<?php echo e(route('own-posts.show', $post->token)); ?>"
                                readonly></td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.custom', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>