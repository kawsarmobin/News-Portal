<?php if(config('archive.archive_check')): ?>
<div class="col-sm-12 col-lg-2 right-bar my-4">
    <div class="card">
        <h5 class="card-header text-center bg-light">Archives</h5>
        <div class="card-body p-0 m-3">
            <div>
                <?php if(count($archives)): ?> <?php $__currentLoopData = $archives; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $archive): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="list-unstyled"><a href="<?php echo e(route('home.archive', ['month'=>$archive->month,'year'=>$archive->year])); ?>"><i class="fa fa-calendar-o" aria-hidden="true"></i> <?php echo e($archive->month_name); ?> <?php echo e($archive->year); ?> (<?php echo e($archive->num_of_posts); ?>)</a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <hr> <?php $__currentLoopData = $archive_years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $archive_y): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="list-unstyled"><a href="<?php echo e(route('home.archive', ['year'=>$archive_y->year])); ?>"><i class="fa fa-calendar" aria-hidden="true"></i> <?php echo e($archive_y->year); ?> (<?php echo e($archive_y->num_of_posts); ?>)</a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <?php else: ?>
                <div>
                    <h6>No archives yet...</h6>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>