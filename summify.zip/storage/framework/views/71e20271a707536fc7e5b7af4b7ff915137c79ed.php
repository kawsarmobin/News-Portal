 
<?php $__env->startSection('content'); ?>
<div class="col-lg-10 p-5">
    <div class="my-4">
        <section id="topics" style="background-color: #FFFFFF">
            <div class="row justify-content-center">
                <div class="col-lg-10 p-5">
                    <h3><b>Create Topic</b></h3>
                    <hr>
                    <form action="<?php echo e(route('topics.store')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label class="control-label">Topic Name: </label>
                            <input class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" type="text" name="name" value="<?php echo e(old('name')); ?>" placeholder="Add a topic name">
                            
                            <?php if($errors->has('name')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('name')); ?></strong>
                                </span>
                            <?php endif; ?>
                                
                            <span class="span"><b>Note: </b>You will be the admin for this topic</span>
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-outline-secondary btn-sm button">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </section>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>